# Démarrage — vos premiers pas + 10 usages concrets

Vous avez installé Hermes Agent et branché un modèle (sinon : `GUIDE.md`, inclus
dans ce kit). Voici comment démarrer pour de bon — et dix choses utiles à lui
faire faire dès aujourd'hui.

> Rappel : toutes ces commandes viennent de la documentation officielle
> (<https://hermes-agent.nousresearch.com/docs>). Copiez les textes entre
> guillemets français « » directement dans la conversation.

---

## Confidentialité — avant de partager un dossier

**Installer Hermes sur votre machine ne signifie pas que le modèle y tourne.**
Avec un fournisseur distant, le contexte sélectionné pour chaque requête est
transmis à ce fournisseur : messages, mémoire et instructions de projet chargées,
résultats d’outils, donc éventuellement extraits de fichiers. Ce n’est pas
nécessairement tout l’historique ni tous les fichiers de votre ordinateur.
Vérifiez le fournisseur et le modèle actifs, ainsi que leurs conditions de conservation
et d’utilisation des données ; ce kit ne les garantit pas.

**Un modèle local ne rend pas les outils hors ligne.** Les outils de recherche web,
la navigation, les serveurs MCP, la messagerie et les commandes du terminal peuvent
contacter d’autres services.
Selon votre configuration, des modèles auxiliaires et des fournisseurs de secours
peuvent aussi traiter du contexte ailleurs. Consultez les réglages dans
`hermes model` et `hermes tools` : choisir le modèle principal ne vérifie pas à
lui seul tous ces accès.

Pour un premier essai, utilisez un dossier de test sans secrets et des droits minimaux ;
limitez les outils et intégrations à ceux nécessaires (voir `GUIDE.md`, section 4).
Si l’absence de sortie réseau est une exigence, il faut un contrôle réseau indépendant,
pas seulement une consigne donnée à l’agent ou le choix d’un modèle local.

**Stockage local ne veut pas dire données éphémères.** L’historique de session,
y compris des résultats d’outils, est enregistré dans `~/.hermes/state.db` par défaut
(le répertoire dépend du profil ou de `HERMES_HOME`). Mémoire, journaux, exports
et sauvegardes peuvent aussi conserver des informations sensibles : protégez ces
copies et relisez tout diagnostic avant de le partager, sans clés ni fichier `.env`.
Compresser le contexte n’est pas un effacement de l’historique stocké.

**Synthèse documentaire du Crabe (IA), vérifiée le 2026-11-24** :
[sessions et contexte sélectionné](https://hermes-agent.nousresearch.com/docs/user-guide/sessions),
[fichiers de contexte](https://hermes-agent.nousresearch.com/docs/user-guide/features/context-files),
[outils](https://hermes-agent.nousresearch.com/docs/user-guide/features/tools),
[modèles auxiliaires](https://hermes-agent.nousresearch.com/docs/user-guide/configuration#auxiliary-models)
et [fournisseurs de secours](https://hermes-agent.nousresearch.com/docs/user-guide/features/fallback-providers).
Ce texte n’est pas un audit réseau, une garantie juridique ou une installation testée.

---

## Premiers pas : un essai limité

**Avant de lancer Hermes**, lisez la section 4 de [GUIDE.md](GUIDE.md) pour le
budget, le fournisseur de modèle et les accès. Préparez :

- Un **environnement isolé sans secrets**, avec les droits limités au nécessaire
  et une **copie de test** : par exemple un fichier `essai.txt` que vous avez
  créé avec quelques lignes fictives. Pas de documents clients, de clés API ni
  de fichiers `.env` dans les données de cet exercice.
- Les seuls outils nécessaires, à examiner avec `hermes tools`. Désactiver les
  outils de fichiers ne bloque pas les accès par le **terminal**. Changer de
  dossier de travail **ne confine pas** l’agent à ce dossier : en backend local,
  les commandes utilisent les droits du compte qui exécute Hermes.
- Des **permissions techniques** adaptées à cet environnement. Une demande
  « lecture seule » **ne remplace pas** ces limites ; les protections des outils
  de fichiers ne couvrent pas à elles seules le terminal. Le kit **ne configure
  ni ne certifie** cette isolation. Si vous ne pouvez pas limiter ces accès,
  ne confiez pas de documents sensibles à ce premier essai.

1. **Vérifiez la santé de l’installation**

   ```bash
   hermes doctor
   ```

   Examinez les avertissements et corrigez les blocages signalés. Ce diagnostic
   n’est **pas un audit de sécurité** ni une preuve que les accès sont limités.

2. **Lancez votre première session** dans l’environnement préparé :

   ```bash
   hermes            # interface classique
   hermes --tui      # autre interface : choisissez une seule commande
   ```

3. **Demandez une seule lecture**, avec le chemin de votre copie de test :

   > « Lis uniquement le fichier essai.txt dans ce dossier de test et résume-le
   > en 3 points. Ne modifie aucun fichier, ne lance aucun script et ne contacte
   > aucun service externe. Si un autre accès est nécessaire, arrête-toi et
   > explique pourquoi. »

   C’est une **consigne de travail**, **pas une barrière technique**. Un **modèle
   distant** peut recevoir le texte lu dans son contexte, même si vous demandez
   de ne pas utiliser de service externe. Vérifiez les **sorties d’outils** et
   comparez le résumé au fichier, sans vous fier au seul message « terminé ».
   Si le périmètre dépasse ce test, interrompez la tâche et revoyez les accès.

4. **Apprenez les trois raccourcis vitaux** : `Ctrl+C` interrompt l’agent,
   `Alt+Entrée` (ou `Ctrl+J`) fait un saut de ligne sans envoyer, `/help` liste
   toutes les commandes.

5. **Reprenez où vous en étiez** : quittez, puis relancez avec `hermes -c` — votre
   dernière session revient. Nommez vos sessions avec `/title recherche-x`
   pour les retrouver ensuite via `hermes sessions list` et `hermes -r "recherche-x"`.

Sources officielles consultées le **2026-11-24** :
[outils activés](https://hermes-agent.nousresearch.com/docs/user-guide/features/tools#using-toolsets),
[limites des protections de fichiers](https://hermes-agent.nousresearch.com/docs/user-guide/security#file-write-safety)
et [isolation du terminal selon le backend](https://hermes-agent.nousresearch.com/docs/user-guide/security#terminal-backend-security-comparison).
Contrôle documentaire uniquement : aucune installation ni isolation testée ici.

---

## 10 usages concrets

### 1. Poser des questions à vos fichiers et dossiers

Après le premier essai, élargissez progressivement le périmètre à une **copie de
travail** sans secrets, avec des accès limités. Les outils disponibles et les droits
du compte déterminent ce que Hermes peut lire ou modifier.
Même avec des permissions limitées, le contenu lu peut rejoindre le contexte envoyé au modèle.

> « Dans cette copie de travail, explique le rôle des fichiers que je t’indique,
> sans modification. Arrête-toi si une lecture sort du périmètre. »
> « Dans cette même copie, liste les références à ‹ ancien-nom ›, sans remplacement. »

Les usages suivants peuvent demander davantage d’accès ou des écritures :
définissez leur périmètre séparément et contrôlez les changements avant de les garder.

### 2. Les petites tâches système du quotidien

> « Quelle est l'utilisation de mon disque ? Montre-moi le top 5 des dossiers les plus lourds. »

Il exécute la commande, lit le résultat et vous le résume — vous n'avez rien à taper.

### 3. Coder et corriger sans se battre

> « Ce test échoue. Trouve pourquoi et corrige-le. »
> « Ajoute une validation des entrées dans cette fonction, en respectant le style du fichier. »

Il cherche, lit, modifie, relance les tests. Vous validez les changements.

### 4. Git et GitHub sans douleur

Dans le terminal, `hermes skills list` liste les skills installées ;
`hermes skills browse` explore le catalogue en ligne, sans garantir leur présence
chez vous. `/github-pr-workflow` est un exemple encore cité dans la documentation,
**pas une commande intégrée** garantie : l’amont vérifié regroupe ces procédures
dans la skill `github`. Vérifiez le nom réellement disponible dans votre **profil actif**.

Une invocation `/<nom-de-skill>` charge des instructions pour l’agent ; elle
**ne donne aucun droit** GitHub et ne garantit pas le résultat. La disponibilité
dépend aussi de la version, de l’interface, des skills activées et des outils.
Lisez la procédure et ses scripts avant de leur faire confiance : **le chargement
n’est pas un mode lecture seule**, l’agent peut agir ensuite. L’option avancée
`skills.inline_shell`, désactivée par défaut, peut même exécuter des commandes
au chargement pour les sources admises ; ne l’activez pas pour cet essai.
Pour les opérations Git/GitHub, vérifiez Git, `gh`, l’authentification et les droits minimaux
nécessaires : la présence de la skill ne prouve pas que ces prérequis sont satisfaits.

Commencez sur une **copie de test sans secrets**, avec des permissions techniques
limitées, puis demandez en langage naturel :

> « Examine ce dépôt de test sans le modifier. Propose une marche à suivre pour
> une PR, sans commit, sans push et sans création de PR. Montre le diff existant
> et les tests à prévoir ; n’exécute pas les scripts du dépôt. »

**Avant toute écriture**, validez le périmètre. Demandez un **accord explicite**
séparé avant commit, push, création de PR, fusion ou publication ; relisez le diff,
les résultats des tests et la destination. Cette consigne ne remplace pas les
permissions techniques ni les contrôles d’approbation de votre environnement.

Sources vérifiées le **2026-11-25** : [skills et invocation](https://hermes-agent.nousresearch.com/docs/user-guide/features/skills),
[commandes du terminal](https://hermes-agent.nousresearch.com/docs/reference/cli-commands),
[chargement et scripts](https://hermes-agent.nousresearch.com/docs/developer-guide/creating-skills)
et [skill GitHub au SHA audité](https://github.com/NousResearch/hermes-agent/blob/2fcdbfea1847a1119901835d5970fdca2b3d8ea8/skills/software-development/github/SKILL.md).

### 5. Veille et recherche web

> « Cherche les actualités récentes sur [sujet] et fais-moi une synthèse avec les sources. »

Hermes dispose d'outils de recherche et d'extraction web natifs ; demandez-lui de
citer les pages consultées, et faites-le creuser une source précise si besoin.

### 6. Une mémoire qui travaille pour vous

La mémoire intégrée peut conserver des faits et préférences dans
`~/.hermes/memories/` par défaut (répertoire propre au profil ou à `HERMES_HOME`).
Ces notes sont chargées dans le contexte du modèle au démarrage d’une session :
leur stockage local ne les rend pas privées vis-à-vis d’un fournisseur distant.

> « Retiens pour la prochaine fois que je travaille sur [projet] et que je préfère les réponses courtes. »

Testez avec des informations sans secrets et vérifiez ce qui a été retenu ; une
mémoire bornée n’est pas une sauvegarde exhaustive. Voir la
[documentation sur la mémoire](https://hermes-agent.nousresearch.com/docs/user-guide/features/memory).

### 7. Transformez vos procédures en skills

`/learn` demande à l’agent de tirer une procédure réutilisable de notes, d’un
fichier, d’une URL ou de la conversation. Ce n’est pas un enregistrement mécanique :
il peut lire les sources avec ses outils, puis écrire un `SKILL.md` via `skill_manage`.
Commencez avec des notes **sans secrets**, une procédure déjà vérifiée et un périmètre limité :

> `/learn À partir de mes notes dans cette conversation, crée une skill pour préparer
> un brouillon d’article local : titre, plan, relecture. N’ouvre aucun back-office,
> ne publie rien et n’effectue aucun déploiement. Indique les étapes non vérifiées.`

**Relisez** le fichier créé, ses références et ses scripts : corrigez les commandes
inventées, les secrets et toute action non autorisée avant réemploi. Vérifiez le
**nom réellement créé** avec `hermes skills list`, puis invoquez `/<nom-de-skill>`
(en remplaçant ce repère par ce nom) ou demandez à Hermes de charger cette skill.
Elle doit être disponible et activée dans le **profil actif** ; les chemins de
stockage et le partage dépendent des réglages, pas d’une disponibilité « partout ».

**Chargement, confiance et permissions sont distincts.** Lire une skill ne valide
ni son auteur ni ses scripts ; un scan n’est pas une garantie. Les outils, accès
aux services et permissions restent à limiter. `/learn` peut créer ou modifier
une skill ; la validation des écritures par `skill_manage` dépend du réglage
d’approbation. L’enregistrer ne la publie pas dans un catalogue et n’autorise pas
les actions qu’elle décrit : conservez les accords séparés de l’usage 4.

Sources vérifiées le **2026-11-25** : [apprentissage et portée des skills](https://hermes-agent.nousresearch.com/docs/user-guide/features/skills)
et [commande /learn](https://hermes-agent.nousresearch.com/docs/reference/slash-commands).
Vérification documentaire uniquement : aucun parcours d’installation ni exemple exécuté ici.

### 8. Automatiser des tâches récurrentes

Hermes sait planifier des tâches en langage naturel. Demandez et il met en place le
rappel ou le rapport :

> « Chaque matin à 8 h, fais-moi la synthèse de ma journée et envoie-la-moi. »

Pour recevoir les résultats sur Telegram ou Discord, désignez le salon d'accueil avec
`/sethome` dedans. Conseil de la doc : ne mettez ça en place qu'après avoir une
configuration de base stable.

### 9. Un assistant personnel sur Telegram ou Discord

```bash
hermes gateway setup     # configuration interactive de la plateforme
hermes gateway status    # vérifier que ça tourne
```

Votre agent devient un bot joignable depuis votre téléphone. **Sécurité** (doc) :
verrouillez l'accès avec des listes d'utilisateurs autorisés
(`TELEGRAM_ALLOWED_USERS`, `DISCORD_ALLOWED_USERS`) ou le système d'appairage ;
jamais `GATEWAY_ALLOW_ALL_USERS=true` pour un bot avec accès au terminal.

### 10. Utiliser un modèle local : coûts et limites du hors-ligne

Le kit et le logiciel Hermes sont **gratuits**. Exécuter un modèle sur votre
machine avec Ollama évite la **facturation API de ce modèle**, pas les coûts de
**matériel**, d’**électricité**, d’un éventuel **hébergement** ou des **outils externes**
activés. **Ollama Cloud** est une offre distincte : choisir Ollama ne suffit pas
à prouver que le modèle tourne sur votre machine.

1. Suivez le [démarrage officiel Ollama](https://docs.ollama.com/quickstart)
   pour votre système, puis choisissez et téléchargez un **modèle local**, pas
   un modèle cloud. Installation et téléchargement nécessitent normalement
   une connexion ; prévoyez-les avant un essai déconnecté.
2. Vérifiez l’**appel d’outils**, les ressources matérielles et le contexte du
   modèle. La documentation Hermes demande **64 000 tokens** de contexte au
   minimum pour l’usage agent avec outils. Configurez le contexte côté serveur
   Ollama et indiquez la même valeur dans Hermes ; un réglage Hermes seul ne
   suffit pas. Le [guide officiel local](https://hermes-agent.nousresearch.com/docs/integrations/providers#ollama--local-models-zero-config)
   explique comment contrôler le contexte effectif avec `ollama ps`.
   Aucun minimum de RAM universel ni fonctionnement sur votre machine n’est garanti.
3. Lorsque le serveur local est prêt : `hermes model` → **Custom endpoint** →
   `http://localhost:11434/v1`, puis le nom exact du modèle installé. L’API locale
   Ollama ne demande pas de clé ; la FAQ Hermes utilise `ollama` comme valeur
   de remplacement si le client en demande une. Ne fournissez pas une clé cloud
   pour ce serveur local et ne l’exposez pas publiquement.

**Un modèle local ne garantit pas le hors-ligne de tout l’agent.** Vérifiez les
**modèles auxiliaires**, les **fournisseurs de secours**, les outils connectés et
les extensions : ils peuvent utiliser d’autres services selon leur configuration.
Examinez les outils avec `hermes tools` ; désactiver le web ne bloque pas à lui seul
le réseau du **terminal**, des scripts ou des extensions.

Commencez avec une copie de test **sans secrets**. Si aucune sortie réseau n’est
acceptable, utilisez un environnement isolé avec un **contrôle réseau indépendant**
et vérifiez les connexions ; le kit n’effectue **pas un audit réseau** et ne
certifie pas ce confinement. Lisez aussi [GUIDE.md](GUIDE.md), section 4,
pour le budget et la confidentialité avant votre premier essai.

Sources officielles consultées le **2026-11-23** :
[modèle local et endpoint](https://hermes-agent.nousresearch.com/docs/reference/faq#can-i-use-it-offline--with-local-models),
[modèles auxiliaires](https://hermes-agent.nousresearch.com/docs/user-guide/configuration#auxiliary-models)
et [fournisseurs de secours](https://hermes-agent.nousresearch.com/docs/integrations/providers#fallback-providers).
C’est un contrôle documentaire, pas une installation ni un test hors-ligne réalisé.

---

## Et après ?

- **Astuce bonus** : `Ctrl+V` colle une capture d'écran directement dans le chat —
  Hermes analyse l'image (utile pour les messages d'erreur ou les maquettes).
- **Suivez la doc** : <https://hermes-agent.nousresearch.com/docs> — chaque page est
  courte et complète.
- **Un blocage ?** `hermes doctor`, puis la [FAQ officielle](https://hermes-agent.nousresearch.com/docs/reference/faq)
  et le Discord de Nous Research. En français : <https://communaute-ia.fr>.
